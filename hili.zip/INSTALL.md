You can install this extension by follow instruction below:
- Download hili.zip by [click here](https://github.com/0xlkda/hili/raw/refs/heads/main/hili.zip) 
- Unzip hili.zip to your prefer directory
- Goto [chrome://extensions](chrome://extensions) using your Chrome Browser
- Find the toggle "Developer Mode" and enable it
- Find the "Load unpacked" and click it
- Select the directory where you unzip the package name "hili.zip"
- Start add your keywords and click save button
- Have fun!
