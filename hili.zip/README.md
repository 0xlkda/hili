Your keywords

![screenshot](screenshot.png) 

Install on [chrome web store](https://chromewebstore.google.com/detail/keyword-highlighter/ibhfgfpimcdfkegpicolnknicecahcph) 
