Your patterns

![screenshot](screenshot.png) 

Install on [Chrome Web Store](https://chromewebstore.google.com/detail/keyword-highlighter/ibhfgfpimcdfkegpicolnknicecahcph) 
Install nightly version [Instruction](INSTALL.md) 
