chrome extension that helps highlighting the list of saved keywords

![screenshot](screenshot.png) 

How to install and use: [View instructions](INSTALL.md) 
