// const KEYWORDS = ['Keyword']
// const KEYWORDS_REGEX = new RegExp(`(${KEYWORDS.join('|')})`, 'gi')
//
// const HIGHLIGHT = (match) => `<mark>${match}</mark>`
// const CENSORED = (match) => `*`.repeat(match.length)
//
// Hili.mark(document.getElementById('Walker'), { 
//   transform: (node) => {
//     node.parentNode.innerHTML = node.parentNode.innerHTML.replaceAll(KEYWORDS_REGEX, HIGHLIGHT)
//   }, 
// })
//
// Hili.mark(document.getElementById('NativeWalker'), { 
//   transform: (node) => {
//     node.parentNode.innerHTML = node.parentNode.innerHTML.replaceAll(KEYWORDS_REGEX, CENSORED)
//   }, 
// })
